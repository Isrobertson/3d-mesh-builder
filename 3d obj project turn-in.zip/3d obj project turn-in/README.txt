Project by: Ian Robertson

date 5/5/2022

IDE used: VS 2019

This project was fun to do even though I didn't get to add the full functionality I would like it to do.
but besides that it still at least outputs a obj file as a plane object.

the hardest part was figuring out how to triangulate and form the tri's and quads but after researching
and experimenting it was pretty straight forward since I was developing something as simple as a plane object

the feature I didn't get to fully develop was the height map generator or "perlin noise" file. what I did wrong
was that I kept using rand instead of an actual perlin noise filter after realizing this I simply didn't have enough time left and
I got the basic functionality I needed at least and thats what mattered to me as a main priority for this project.

	-- I left the "perlin noise" files in to show what I was going for at first I thought it was interesting --

I plan on going back to this project later and refactor it while figuring out how to implement the height map
generator as I would love to add this to my profolio on what I am capable of as a programmer!

Final thoughts on the class:
	thank you for the semester Professor Moscardelli! I really learned alot taking this class! I look forward to improving
my skills in software engineering while striving to keep learning and sharpening my skills. I hope you have a great summer
and I will look back to this class when I am at eastern and/or at my career job sometime soon. thank you and take care!