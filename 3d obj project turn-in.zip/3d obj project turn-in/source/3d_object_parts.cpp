#include <iostream>
#include "header/classes/3d_object_parts.h"

int Vertex::globalID = 0;