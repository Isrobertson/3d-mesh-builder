#pragma once
#include "classes/3d_object.h"

void determineVertexHeight(Vertexlist&);