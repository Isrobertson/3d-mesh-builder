#pragma once
#include "classes/3d_object.h"
// file that will handle outputting to a file

void outputFile(std::vector<Object*>&);