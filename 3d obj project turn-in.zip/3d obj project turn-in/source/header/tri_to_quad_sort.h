#pragma once
#include "classes/3d_object_parts.h"

void sortTrisToQuad(Vertexlist&);